package interactive_fiction.test;

public class ExternalImplP9 implements interactive_fiction.long_story.External{

	@Override
	public boolean isEven(int param0) {
		return param0 % 2 == 0;
	}

	@Override
	public int textLength(String param2) {
		return param2.length();
	}

	@Override
	public int absolute(int param2) {
		return Math.abs(param2);
	}

}
