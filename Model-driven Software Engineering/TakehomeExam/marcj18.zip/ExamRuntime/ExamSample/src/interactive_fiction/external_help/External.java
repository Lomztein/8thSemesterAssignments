package interactive_fiction.external_help;

public interface External {
	public boolean isEven(int param0);
	public boolean isFavorite(String param1);
	public int textLength(String param2);
}
