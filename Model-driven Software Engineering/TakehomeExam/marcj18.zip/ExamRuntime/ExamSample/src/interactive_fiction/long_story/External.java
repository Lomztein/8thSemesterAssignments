package interactive_fiction.long_story;

public interface External {
	public int textLength(String param0);
	public boolean isEven(int param1);
	public int absolute(int param2);
}
