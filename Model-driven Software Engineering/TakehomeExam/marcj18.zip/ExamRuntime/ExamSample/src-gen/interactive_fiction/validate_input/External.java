
package interactive_fiction.validate_input;

public interface External {
}
