
package interactive_fiction.false_interaction;

public interface External {
}
