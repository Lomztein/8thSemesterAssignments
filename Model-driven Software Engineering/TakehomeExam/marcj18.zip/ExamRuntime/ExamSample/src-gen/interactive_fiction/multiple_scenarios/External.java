
package interactive_fiction.multiple_scenarios;

public interface External {
}
