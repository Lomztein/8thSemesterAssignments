
package interactive_fiction.long_story;

public interface External {
	public int textLength(String a);
	public boolean isEven(int b);
	public int absolute(int c);
}
