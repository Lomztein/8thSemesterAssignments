
package interactive_fiction.external_help;

public interface External {
	public boolean isEven(int d);
	public boolean isFavorite(String e);
	public int textLength(String f);
}
