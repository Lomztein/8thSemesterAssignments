
package interactive_fiction.book;

public interface External {
}
