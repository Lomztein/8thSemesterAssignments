
package interactive_fiction.short_story;

public interface External {
}
