
package interactive_fiction.first_interaction;

public interface External {
}
