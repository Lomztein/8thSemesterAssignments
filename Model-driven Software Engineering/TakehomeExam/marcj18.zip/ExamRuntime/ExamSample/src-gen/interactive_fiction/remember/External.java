
package interactive_fiction.remember;

public interface External {
}
